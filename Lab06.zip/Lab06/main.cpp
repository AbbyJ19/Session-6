#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

enum class Status { PASS, FAIL };

struct Student {
    int id;
    std::string name;
    double marks[3];
    double average;
    Status status;
};

const double PASS_MARK = 50.0;
const char* const DATA_FILE = "students.txt";


const char* statusText(Status s) { return s == Status::PASS ? "PASS" : "FAIL"; }

void computeResult(Student& s) {
    s.average = (s.marks[0] + s.marks[1] + s.marks[2]) / 3.0;
    s.status = (s.average >= PASS_MARK) ? Status::PASS : Status::FAIL;
}

bool readLine(const std::string& prompt, std::string& out) {
    std::cout << prompt;
    return static_cast<bool>(std::getline(std::cin, out));
}

bool readInt(const std::string& prompt, int lo, int hi, int& value) {
    std::string line;
    while (true) {
        if (!readLine(prompt, line)) return false;
        std::istringstream iss(line);
        int v;
        char extra;
        if (iss >> v && !(iss >> extra) && v >= lo && v <= hi) {
            value = v;
            return true;
        }
        std::cout << "  Invalid input. Enter a whole number from " << lo << " to " << hi << ".\n";
    }
}

bool readMark(const std::string& prompt, double& value) {
    std::string line;
    while (true) {
        if (!readLine(prompt, line)) return false;
        std::istringstream iss(line);
        double v;
        char extra;
        if (iss >> v && !(iss >> extra) && v >= 0.0 && v <= 100.0) {
            value = v;
            return true;
        }
        std::cout << "  Invalid mark. Enter a number from 0 to 100.\n";
    }
}

int findIndexById(const std::vector<Student>& list, int id) {
    for (size_t i = 0; i < list.size(); i++)
        if (list[i].id == id) return static_cast<int>(i);
    return -1;
}

void printHeader() {
    std::cout << std::left << std::setw(7) << "ID" << std::setw(16) << "Name"
              << std::setw(8) << "M1" << std::setw(8) << "M2" << std::setw(8) << "M3"
              << std::setw(10) << "Average" << "Status\n"
              << std::string(65, '-') << "\n";
}

void printRow(const Student& s) {
    std::cout << std::left << std::fixed << std::setprecision(2)
              << std::setw(7) << s.id << std::setw(16) << s.name
              << std::setw(8) << s.marks[0] << std::setw(8) << s.marks[1]
              << std::setw(8) << s.marks[2] << std::setw(10) << s.average
              << statusText(s.status) << "\n";
}

void registerStudent(std::vector<Student>& list) {
    Student s{};
    if (!readInt("Student ID (1-999999): ", 1, 999999, s.id)) return;
    if (findIndexById(list, s.id) != -1) {
        std::cout << "  Error: ID " << s.id << " already exists. Registration cancelled.\n";
        return;
    }
    while (true) {
        if (!readLine("Full name: ", s.name)) return;
        if (s.name.empty() || s.name.find('|') != std::string::npos) {
            std::cout << "  Name cannot be empty or contain '|'.\n";
            continue;
        }
        break;
    }
    for (int i = 0; i < 3; i++) {
        if (!readMark("Mark " + std::to_string(i + 1) + " (0-100): ", s.marks[i])) return;
    }
    computeResult(s);
    list.push_back(s);
    std::cout << "  Student registered. Average " << std::fixed << std::setprecision(2)
              << s.average << " -> " << statusText(s.status) << "\n";
}

void listStudents(const std::vector<Student>& list) {
    if (list.empty()) {
        std::cout << "  No students registered yet.\n";
        return;
    }
    printHeader();
    for (const Student& s : list) printRow(s);
}

void searchStudent(const std::vector<Student>& list) {
    if (list.empty()) {
        std::cout << "  No students registered yet.\n";
        return;
    }
    int id;
    if (!readInt("ID to search: ", 1, 999999, id)) return;
    int idx = findIndexById(list, id);
    if (idx == -1) {
        std::cout << "  No student with ID " << id << ".\n";
        return;
    }
    printHeader();
    printRow(list[static_cast<size_t>(idx)]);
}

void updateMarks(std::vector<Student>& list) {
    if (list.empty()) {
        std::cout << "  No students registered yet.\n";
        return;
    }
    int id;
    if (!readInt("ID to update: ", 1, 999999, id)) return;
    int idx = findIndexById(list, id);
    if (idx == -1) {
        std::cout << "  No student with ID " << id << ".\n";
        return;
    }
    Student& s = list[static_cast<size_t>(idx)];
    double newMarks[3];
    for (int i = 0; i < 3; i++) {
        if (!readMark("New mark " + std::to_string(i + 1) + " (0-100): ", newMarks[i])) return;
    }
    for (int i = 0; i < 3; i++) s.marks[i] = newMarks[i];
    computeResult(s);
    std::cout << "  Updated. New average " << std::fixed << std::setprecision(2)
              << s.average << " -> " << statusText(s.status) << "\n";
}

void classStatistics(const std::vector<Student>& list) {
    if (list.empty()) {
        std::cout << "  No students registered yet.\n";
        return;
    }
    double sum = 0;
    for (const Student& s : list) sum += s.average;
    auto byAvg = [](const Student& a, const Student& b) { return a.average < b.average; };
    const Student& lowest = *std::min_element(list.begin(), list.end(), byAvg);
    const Student& highest = *std::max_element(list.begin(), list.end(), byAvg);
    auto passes = std::count_if(list.begin(), list.end(),
                                [](const Student& s) { return s.status == Status::PASS; });

    std::cout << std::fixed << std::setprecision(2);
    std::cout << "  Students      : " << list.size() << "\n";
    std::cout << "  Class average : " << sum / static_cast<double>(list.size()) << "\n";
    std::cout << "  Highest avg   : " << highest.average << "\n";
    std::cout << "  Lowest avg    : " << lowest.average << "\n";
    std::cout << "  Passed        : " << passes << "\n";
    std::cout << "  Failed        : " << static_cast<long>(list.size()) - passes << "\n";
}

void topStudent(const std::vector<Student>& list) {
    if (list.empty()) {
        std::cout << "  No students registered yet.\n";
        return;
    }
    double best = std::max_element(list.begin(), list.end(),
                                   [](const Student& a, const Student& b) { return a.average < b.average; })
                      ->average;
    std::vector<Student> top;
    std::copy_if(list.begin(), list.end(), std::back_inserter(top),
                 [best](const Student& s) { return s.average == best; });
    std::cout << (top.size() > 1 ? "  TIE for top student:\n" : "  Top student:\n");
    printHeader();
    for (const Student& s : top) printRow(s);
}

void passList(const std::vector<Student>& list) {
    std::vector<Student> passed;
    std::copy_if(list.begin(), list.end(), std::back_inserter(passed),
                 [](const Student& s) { return s.status == Status::PASS; });
    if (passed.empty()) {
        std::cout << "  No passing students.\n";
        return;
    }
    std::stable_sort(passed.begin(), passed.end(),
                     [](const Student& a, const Student& b) { return a.average > b.average; });
    printHeader();
    for (const Student& s : passed) printRow(s);
}


void saveToFile(const std::vector<Student>& list) {
    std::ofstream out(DATA_FILE);
    if (!out) {
        std::cout << "  Could not save to " << DATA_FILE << ".\n";
        return;
    }
    for (const Student& s : list)
        out << s.id << '|' << s.name << '|' << s.marks[0] << '|' << s.marks[1] << '|' << s.marks[2] << '\n';
    std::cout << "  Saved " << list.size() << " record(s) to " << DATA_FILE << ".\n";
}

std::vector<Student> loadFromFile() {
    std::vector<Student> list;
    std::ifstream in(DATA_FILE);
    if (!in) return list;
    std::string line;
    int skipped = 0;
    while (std::getline(in, line)) {
        std::vector<std::string> parts;
        std::stringstream ss(line);
        std::string piece;
        while (std::getline(ss, piece, '|')) parts.push_back(piece);
        bool ok = (parts.size() == 5);
        Student s{};
        if (ok) {
            try {
                size_t pos = 0;
                s.id = std::stoi(parts[0], &pos);
                ok = (pos == parts[0].size()) && s.id >= 1;
                s.name = parts[1];
                ok = ok && !s.name.empty();
                for (int i = 0; i < 3 && ok; i++) {
                    s.marks[i] = std::stod(parts[static_cast<size_t>(i) + 2], &pos);
                    ok = (pos == parts[static_cast<size_t>(i) + 2].size()) && s.marks[i] >= 0 && s.marks[i] <= 100;
                }
            } catch (...) {
                ok = false;
            }
        }
        if (ok && findIndexById(list, s.id) == -1) {
            computeResult(s);
            list.push_back(s);
        } else if (!line.empty()) {
            skipped++;
        }
    }
    if (skipped > 0) std::cout << "(Skipped " << skipped << " invalid line(s) in " << DATA_FILE << ")\n";
    return list;
}

std::vector<Student> sampleData() {
    std::vector<Student> v = {
        {101, "Alice Ngu", {80, 75, 90}, 0, Status::FAIL},
        {102, "Brice Tabi", {45, 50, 40}, 0, Status::FAIL},
        {103, "Clarisse Eto", {60, 65, 70}, 0, Status::FAIL},
        {104, "Daniel Fon", {30, 55, 49}, 0, Status::FAIL},
        {105, "Estelle Mba", {95, 88, 92}, 0, Status::FAIL},
        {106, "Franck Ewane", {50, 50, 50}, 0, Status::FAIL},
        {107, "Grace Atem", {70, 72, 68}, 0, Status::FAIL},
        {108, "Herve Njoya", {20, 35, 40}, 0, Status::FAIL},
        {109, "Ines Kamga", {85, 90, 95}, 0, Status::FAIL},
        {110, "Junior Bella", {62, 58, 66}, 0, Status::FAIL},
    };
    for (Student& s : v) computeResult(s);
    return v;
}


int main(int argc, char* argv[]) {
    std::vector<Student> students;
    if (argc > 1 && std::string(argv[1]) == "--empty") {
        
    } else {
        students = loadFromFile();
        if (students.empty()) students = sampleData();
    }

    int choice = 0;
    do {
        std::cout << "\n===== STUDENT ACADEMIC MANAGEMENT SYSTEM =====\n"
                  << "1. Register\n2. List\n3. Search by ID\n4. Update marks\n"
                  << "5. Class statistics\n6. Top student\n7. Pass list\n8. Exit\n";
        if (!readInt("Choice: ", 1, 8, choice)) {
            std::cout << "\nInput ended. Exiting.\n";
            break;
        }
        switch (choice) {
            case 1: registerStudent(students); break;
            case 2: listStudents(students); break;
            case 3: searchStudent(students); break;
            case 4: updateMarks(students); break;
            case 5: classStatistics(students); break;
            case 6: topStudent(students); break;
            case 7: passList(students); break;
            case 8:
                saveToFile(students);
                std::cout << "Goodbye!\n";
                break;
            default: break;
        }
    } while (choice != 8);
    return 0;
}
